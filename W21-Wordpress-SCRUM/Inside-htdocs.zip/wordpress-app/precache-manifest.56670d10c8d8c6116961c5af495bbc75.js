self.__precacheManifest = [
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "ebb41a5acc7901410f42",
    "url": "/static/js/main.ebb41a5a.chunk.js"
  },
  {
    "revision": "f739feb7d61c48a46bed",
    "url": "/static/js/1.f739feb7.chunk.js"
  },
  {
    "revision": "ebb41a5acc7901410f42",
    "url": "/static/css/main.4882533c.chunk.css"
  },
  {
    "revision": "936dcf1ffb2b5036b8a857620e11e850",
    "url": "/index.html"
  }
];